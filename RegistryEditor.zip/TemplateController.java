package com.reg.regedit;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.stage.FileChooser;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

public class TemplateController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button addrow;


    @FXML
    private Button rowdel;

    @FXML
    private Button buttonsave;

    @FXML
    private TableView<RowData> templtable;

    @FXML
    private TableColumn<RowData, String> columcol;

    @FXML
    private TableColumn<RowData, String> comcol;

    @FXML
    private TableColumn<RowData, String> firstcol;

    @FXML
    private TableColumn<RowData, String> infocol;

    @FXML
    private TableColumn<RowData, String> rowcol;

    @FXML
    private Button filesavebutton;

    @FXML
    private Label filelable;
    private int actions;

    private String filePaths;

    private boolean templchecks = true;

    private int count = 0;

    @FXML
    void initialize() {

        tableinit();

        if(templtable.getItems().size()==0){

        }
        rowdel.setDisable(true);

        filelable.setDisable(true);
        filesavebutton.setDisable(true);
        buttonsave.setDisable(true);

        addrow.setOnAction(actionEvent -> {
            buttonsave.setDisable(false);
            rowdel.setDisable(false);
            RowData rowData = new RowData();
            for(int i =0;i<templtable.getItems().size()+1;i++) {
                rowData.addCommentcellData("");
                rowData.addRowcellData("");
                rowData.addInfocellData("");
                rowData.addColumncellData("");
            }
            templtable.getItems().add(rowData);
        });

        buttonsave.setOnAction(actionEvent -> {
            saveasTeml();
        });

        filesavebutton.setOnAction(actionEvent -> {
            saveTempl();
        });


        rowdel.setOnAction(actionEvent -> {
            deletingRow();
        });
    }

    public TemplateController(){
    }

    private void loadTempl(String filename,boolean type){

    }

    public void setTemplatedata(String filePath, int action, boolean templcheck) {
        this.actions = action;
        this.filePaths = filePath;
        this.templchecks = templcheck;
        if (actions == 1) {
            filesavebutton.setDisable(false);
            buttonsave.setDisable(false);
            filelable.setDisable(false);
            rowdel.setDisable(false);
            filelable.setText("Текущий шаблон: " + filePaths);
            int rowCount;
            Tuple<Integer, Integer> item1;
            Tuple<String, String> item2;
            if(templcheck == true) {
                rowCount = Model.getFirstTemplate().size();
            }
            else {
                rowCount = Model.getSecondTemplate().size();
            }
            for (int i = 0; i < rowCount; i++) {
                RowData rowData = new RowData();
                for(int j=0;j<templtable.getItems().size();j++) {
                    rowData.addCommentcellData("");
                    rowData.addRowcellData("");
                    rowData.addInfocellData("");
                    rowData.addColumncellData("");
                }
                if(templcheck == true) {
                     item1 = Model.getFirstTemplate().get(i).getItem1();
                    item2 = Model.getFirstTemplate().get(i).getItem2();
                }
                else{
                    item1 = Model.getSecondTemplate().get(i).getItem1();
                    item2 = Model.getSecondTemplate().get(i).getItem2();
                }
                    rowData.addRowcellData(String.format("%02X", item1.getItem1()));
                    rowData.addColumncellData(String.format("%02X", item1.getItem2()));


                    rowData.addInfocellData(item2.getItem1());
                    rowData.addCommentcellData(item2.getItem2());
                    templtable.getItems().add(rowData);
            }
            templtable.refresh();
        }
    }


    private void saveTempl(){
        int rowCount = templtable.getItems().size();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Сохранение файла");
        alert.setHeaderText(null);
        for (int i = 0; i < rowCount; i++) {

            RowData rowsData = templtable.getItems().get(i);

            if (rowsData.getColumncellData().get(rowsData.getColumncellData().size()-1) == "" || rowsData.getRowcellData().get(rowsData.getRowcellData().size()-1) == "" || rowsData.getInfocellData().get(rowsData.getInfocellData().size()-1) == "") {
                showAlert("Все столбцы, кроме комментария должны быть заполнены!",
                        "Ошибка");
                return;
            }
            rowsData.getInfocellData().get(i).trim();
            rowsData.getColumncellData().get(i).trim();
            if (rowsData.getCommentcellData().size()>0)
                rowsData.getCommentcellData().get(i).trim();
        }
            StringBuilder error = new StringBuilder();
            if (!Model.saveTemplate(filePaths, templtable, error)) {
                showAlert(error.toString(), "Ошибка!");
            } else {
                StringBuilder err = new StringBuilder();
                if(templchecks == true) {
                    Model.loadTemplate(filePaths, Model.FIRST, err);
                }
                else {
                    Model.loadTemplate(filePaths, Model.SECOND, err);
                }
                alert.setContentText("Файл успешно сохранен.");
                alert.showAndWait();
            }
    }




    private void saveasTeml() {
        int rowCount = templtable.getItems().size();

        for (int i = 0; i < rowCount; i++) {
            RowData rowsData = templtable.getItems().get(i);

            if (rowsData.getColumncellData().get(rowsData.getColumncellData().size()-1) == "" || rowsData.getRowcellData().get(rowsData.getRowcellData().size()-1) == "" || rowsData.getInfocellData().get(rowsData.getInfocellData().size()-1) == "") {
                showAlert("Все столбцы, кроме комментария должны быть заполнены!",
                        "Ошибка");
                return;
            }

            rowsData.getInfocellData().get(i).trim();
            rowsData.getColumncellData().get(i).trim();
            if (rowsData.getCommentcellData().size()>0)
                rowsData.getCommentcellData().get(i).trim();
        }
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Сохранить файл");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Файлы", "*.tmpl"));

        File file = fileChooser.showSaveDialog(null);
        if (file != null) {
            StringBuilder error = new StringBuilder();
            if (!Model.saveTemplate(file.getPath(), templtable, error)) {
                showAlert(error.toString(), "Ошибка!");
            }
            else{
                filePaths = file.getPath();
                filesavebutton.setDisable(false);
                filelable.setDisable(false);
                filelable.setText("Текущий шаблон: " + filePaths);

            }
        }


    }



    private void tableinit() {

        columcol.setReorderable(false);
        comcol.setReorderable(false);
        firstcol.setReorderable(false);
        infocol.setReorderable(false);
        rowcol.setReorderable(false);
        templtable.getSelectionModel().setCellSelectionEnabled(false);

        templtable.setEditable(true);

           columcol.setCellValueFactory(cellData -> {
               if(templtable.getItems().size() == 1){}
               int rowIndex = cellData.getTableView().getItems().indexOf(cellData.getValue());
               RowData rowData = cellData.getValue();
               String columnCellData;
               ObservableList<String> columnCellDataList = rowData.getColumncellData();
               if (rowIndex < columnCellDataList.size()) {
                   columnCellData = columnCellDataList.get(rowIndex);
                   if (columnCellData != null) {
                       return new SimpleStringProperty(columnCellData);
                   }
               }
               else {
                   columnCellData = columnCellDataList.get(0);
                   if (columnCellData != null) {
                       return new SimpleStringProperty(columnCellData);
                   }
                   else{
                       columnCellData = "";
                   }
               }
               return new SimpleStringProperty(columnCellData);
           });




        columcol.setCellFactory(column -> {
            return new TableCell<RowData, String>() {
                private final TextField textField = new TextField();
                private final Tooltip tooltip = new Tooltip();

                {
                    textField.setOnKeyPressed(event -> {
                        if (event.getCode() == KeyCode.ENTER) {
                            commitEdit(textField.getText());
                        } else if (event.getCode() == KeyCode.ESCAPE) {
                            cancelEdit();
                        }
                    });
                }

                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (isEditing()) {
                        setText(null);
                        setGraphic(textField);
                    } else {
                        setText(item);
                        setGraphic(null);
                    }
                    if (empty || item == null) {
                        setTooltip(null);
                        textField.requestFocus();
                    } else {
                        tooltip.setText(item);
                        setTooltip(tooltip);
                        setGraphic(null);
                    }
                }

                @Override
                public void startEdit() {
                    super.startEdit();

                    textField.setText(getItem());
                    setText(null);
                    setGraphic(textField);
                    textField.requestFocus();
                }

                @Override
                public void cancelEdit() {
                    super.cancelEdit();
                    setText(getItem());
                    setGraphic(null);

                }

                @Override
                public void commitEdit(String newValue) {
                    super.commitEdit(newValue);
                    TablePosition<RowData, String> pos = getTableView().getSelectionModel().getSelectedCells().get(0);
                    int row = pos.getRow();
                    int column = pos.getColumn() ;
                    RowData rowData = getTableView().getItems().get(row);
                    String prevValue = new String();
                    if(rowData.getColumncellData().size()>0) {
                        prevValue = rowData.getColumncellData().get(row);
                    }
                    if(newValue != null && !newValue.trim().matches("^(0[0-9A-F])$")){
                        showAlert("Значение должно быть от 00 до 0F", "Ошибка ввода");
                        rowData.setColumncellData(row,prevValue);
                        getTableView().refresh();
                        return;
                    }
                    if (newValue!=null) {
                        rowData.setColumncellData(row,newValue);
                        getTableView().refresh();

                    } else {
                        rowData.setColumncellData(row,prevValue);
                        getTableView().refresh();
                    }
                }
            };
        });



        rowcol.setCellValueFactory(cellData -> {
            int rowIndex = cellData.getTableView().getItems().indexOf(cellData.getValue());
            RowData rowData = cellData.getValue();
            ObservableList<String> rowCellDataList = rowData.getRowcellData();
            String rowCellData;
            if (rowIndex < rowCellDataList.size()) {
                rowCellData = rowCellDataList.get(rowIndex);
                if (rowCellData !=null ) {
                    return new SimpleStringProperty(rowCellData);
                }
            }
            else {
                rowCellData = rowCellDataList.get(0);
                if (rowCellData != null) {
                    return new SimpleStringProperty(rowCellData);
                }
                else{
                    rowCellData = "";
                }
            }
            return new SimpleStringProperty(rowCellData);
        });
        rowcol.setCellFactory(column -> {
            return new TableCell<RowData, String>() {
                private final TextField textField = new TextField();
                private final Tooltip tooltip = new Tooltip();

                {
                    textField.setOnKeyPressed(event -> {
                        if (event.getCode() == KeyCode.ENTER) {
                            commitEdit(textField.getText());
                        } else if (event.getCode() == KeyCode.ESCAPE) {
                            cancelEdit();
                        }
                    });
                }

                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (isEditing()) {
                        setText(null);
                        setGraphic(textField);
                    } else {
                        setText(item);
                        setGraphic(null);
                    }
                    if (empty || item == null) {
                        setTooltip(null);
                        textField.requestFocus();
                    } else {
                        tooltip.setText(item);
                        setTooltip(tooltip);
                        setGraphic(null);
                    }
                }

                @Override
                public void startEdit() {
                    super.startEdit();

                    textField.setText(getItem());
                    setText(null);
                    setGraphic(textField);
                    textField.requestFocus();
                }

                @Override
                public void cancelEdit() {
                    super.cancelEdit();
                    setText(getItem());
                    setGraphic(null);

                }

                @Override
                public void commitEdit(String newValue) {
                    super.commitEdit(newValue);
                    TablePosition<RowData, String> pos = getTableView().getSelectionModel().getSelectedCells().get(0);
                    int row = pos.getRow();
                    int column = pos.getColumn() ;
                    RowData rowData = getTableView().getItems().get(row);
                    String prevValue = new String();
                    if(rowData.getInfocellData().size()>0) {
                        prevValue = rowData.getRowcellData().get(row);
                    }
                    if (newValue!= null && !newValue.trim().matches("^([0-9A-Fa-f]{1,})$")) {
                        showAlert("Значение должно быть шестнадцатиричным числом", "Ошибка ввода");
                        rowData.setRowcellData(row,prevValue);
                        getTableView().refresh();
                        return;
                    }
                    if (newValue!=null) {
                        rowData.setRowcellData(row,newValue);
                        getTableView().refresh();

                    } else {
                        rowData.setRowcellData(row,prevValue);
                        getTableView().refresh();
                    }
                }
            };
        });

        infocol.setCellValueFactory(cellData -> {
            int rowIndex = cellData.getTableView().getItems().indexOf(cellData.getValue());
            RowData rowData = cellData.getValue();
            ObservableList<String> infoCellDataList = rowData.getInfocellData();
            String infoCellData;
            if (rowIndex < infoCellDataList.size()) {
                infoCellData = infoCellDataList.get(rowIndex);
                if (infoCellData !=null ) {
                    return new SimpleStringProperty(infoCellData);
                }
            }
            else {
                infoCellData = infoCellDataList.get(0);
                if (infoCellData != null) {
                    return new SimpleStringProperty(infoCellData);
                }
                else{
                    infoCellData = "";
                }
            }
            return new SimpleStringProperty(infoCellData);
        });
        infocol.setCellFactory(column -> {
            return new TableCell<RowData, String>() {
                private final TextField textField = new TextField();
                private final Tooltip tooltip = new Tooltip();

                {
                    textField.setOnKeyPressed(event -> {
                        if (event.getCode() == KeyCode.ENTER) {
                            commitEdit(textField.getText());
                        } else if (event.getCode() == KeyCode.ESCAPE) {
                            cancelEdit();
                        }
                    });
                }

                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (isEditing()) {
                        setText(null);
                        setGraphic(textField);
                    } else {
                        setText(item);
                        setGraphic(null);
                    }
                    if (empty || item == null) {
                        setTooltip(null);
                        textField.requestFocus();
                    } else {
                        tooltip.setText(item);
                        setTooltip(tooltip);
                        setGraphic(null);
                    }
                }

                @Override
                public void startEdit() {
                    super.startEdit();

                    textField.setText(getItem());
                    setText(null);
                    setGraphic(textField);
                    textField.requestFocus();
                }

                @Override
                public void cancelEdit() {
                    super.cancelEdit();
                    setText(getItem());
                    setGraphic(null);

                }

                @Override
                public void commitEdit(String newValue) {
                    super.commitEdit(newValue);
                    TablePosition<RowData, String> pos = getTableView().getSelectionModel().getSelectedCells().get(0);
                    int row = pos.getRow();
                    int column = pos.getColumn() ;
                    RowData rowData = getTableView().getItems().get(row);
                    String prevValue = new String();
                    if(rowData.getInfocellData().size()>0) {
                        prevValue = rowData.getInfocellData().get(row);
                    }
                    if (newValue!= null && !newValue.trim().matches("^([0-9A-Fa-f]{1,})$")) {
                        showAlert("Значение должно быть шестнадцатиричным числом", "Ошибка ввода");
                        rowData.setInfocellData(row,prevValue);
                        getTableView().refresh();
                        return;
                    }
                    if (newValue!=null) {
                        rowData.setInfocellData(row,newValue);
                        getTableView().refresh();

                    } else {
                        rowData.setInfocellData(row,prevValue);
                        getTableView().refresh();
                    }
                }
            };
        });

        comcol.setCellValueFactory(cellData -> {
            int rowIndex = cellData.getTableView().getItems().indexOf(cellData.getValue());
            RowData rowData = cellData.getValue();
            ObservableList<String> commentCellDataList = rowData.getCommentcellData();
            String commentCellData;
            if (rowIndex < commentCellDataList.size()) {
                commentCellData = commentCellDataList.get(rowIndex);
                if (commentCellData !=null ) {
                    return new SimpleStringProperty(commentCellData);
                }
            }
            else {
                commentCellData = commentCellDataList.get(0);
                if (commentCellData != null) {
                    return new SimpleStringProperty(commentCellData);
                }
                else{
                    commentCellData = "";
                }
            }
            return new SimpleStringProperty(commentCellData);
        });
        comcol.setCellFactory(column -> {
            return new TableCell<RowData, String>() {
                private final TextField textField = new TextField();
                private final Tooltip tooltip = new Tooltip();

                {
                    textField.setOnKeyPressed(event -> {
                        if (event.getCode() == KeyCode.ENTER) {
                            commitEdit(textField.getText());
                        } else if (event.getCode() == KeyCode.ESCAPE) {
                            cancelEdit();
                        }
                    });
                }

                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (isEditing()) {
                        setText(null);
                        setGraphic(textField);
                    } else {
                        setText(item);
                        setGraphic(null);
                    }
                    if (empty || item == null) {
                        setTooltip(null);
                        textField.requestFocus();
                    } else {
                        tooltip.setText(item);
                        setTooltip(tooltip);
                        setGraphic(null);
                    }
                }

                @Override
                public void startEdit() {
                    super.startEdit();

                    textField.setText(getItem());
                    setText(null);
                    setGraphic(textField);
                    textField.requestFocus();
                }

                @Override
                public void cancelEdit() {
                    super.cancelEdit();
                    setText(getItem());
                    setGraphic(null);

                }

                @Override
                public void commitEdit(String newValue) {
                    super.commitEdit(newValue);
                    TablePosition<RowData, String> pos = getTableView().getSelectionModel().getSelectedCells().get(0);
                    int row = pos.getRow();
                    int column = pos.getColumn() ;
                    RowData rowData = getTableView().getItems().get(row);
                    String prevValue = new String();
                    if(rowData.getCommentcellData().size()>0) {
                        prevValue = rowData.getCommentcellData().get(row);
                    }
                    if (newValue != null && newValue.trim().contains("#")) {
                        showAlert("Нельзя использовать символ \"#\"", "Ошибка ввода");
                        rowData.setCommentcellData(row,prevValue);
                        getTableView().refresh();
                        return;
                    }
                    if (newValue!=null) {
                        rowData.setCommentcellData(row,newValue);
                        getTableView().refresh();

                    } else {
                        rowData.setCommentcellData(row,prevValue);
                        getTableView().refresh();
                    }
                }

            };

        });

        templtable.refresh();
    }



    private void showAlert(String message, String title) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    private void deletingRow(){
        ObservableList<RowData> data = templtable.getItems(); // Список элементов таблицы


        int selectedIndex = templtable.getSelectionModel().getSelectedIndex();


        if (selectedIndex >= 0) {
            RowData checkdata = data.get(selectedIndex);

            data.remove(selectedIndex);


            if (selectedIndex < data.size() && checkdata.getRowcellData().get(checkdata.getRowcellData().size()-1) != "" || checkdata.getColumncellData().get(checkdata.getColumncellData().size()-1) != "" || checkdata.getInfocellData().get(checkdata.getInfocellData().size()-1) != "") {
                for (int i = selectedIndex; i < data.size(); i++) {
                    data.get(i).getColumncellData().remove(0);
                    data.get(i).getRowcellData().remove(0);
                    data.get(i).getInfocellData().remove(0);
                    data.get(i).getCommentcellData().remove(0);
                    RowData currentRow = data.get(i);


                }
            }
            if(data.size()-1>0) {
                RowData lastrow = data.get(data.size() - 1);
                // Проверка и удаление последней пустой строки
                if (lastrow.getRowcellData().get(lastrow.getRowcellData().size() - 1) == "" && lastrow.getColumncellData().get(lastrow.getColumncellData().size() - 1) == "" && lastrow.getInfocellData().get(lastrow.getInfocellData().size() - 1) == "" && lastrow.getCommentcellData().get(lastrow.getCommentcellData().size() - 1) == "") {

                    data.remove(data.size() - 1);
                }
            }

            // Обновление таблицы
            templtable.refresh();
        }
    }


}

