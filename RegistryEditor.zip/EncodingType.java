package com.reg.regedit;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;

public class EncodingType {
    public static Charset getType(String fileName) throws IOException {
        try (FileInputStream fs = new FileInputStream(fileName)) {
            Charset encoding = getType(fs);
            return encoding;
        }
    }

    public static Charset getType(FileInputStream fs) throws IOException {
        byte[] unicode = new byte[]{(byte) 0xFF, (byte) 0xFE, (byte) 0x41};
        byte[] unicodeBig = new byte[]{(byte) 0xFE, (byte) 0xFF, (byte) 0x00};
        byte[] utf8 = new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF}; // with BOM

        Charset reVal = Charset.defaultCharset();
        byte[] ss = new byte[fs.available()];
        fs.read(ss);

        if (isUTF8Bytes(ss) || (ss[0] == (byte) 0xEF && ss[1] == (byte) 0xBB && ss[2] == (byte) 0xBF)) {
            reVal = Charset.forName("UTF-8");
        } else if (ss[0] == (byte) 0xFE && ss[1] == (byte) 0xFF && ss[2] == (byte) 0x00) {
            reVal = Charset.forName("UTF-16BE");
        } else if (ss[0] == (byte) 0xFF && ss[1] == (byte) 0xFE && ss[2] == (byte) 0x41) {
            reVal = Charset.forName("UTF-16LE");
        }

        return reVal;
    }

    private static boolean isUTF8Bytes(byte[] data) {
        int charByteCounter = 1;
        byte curByte;
        for (int i = 0; i < data.length; i++) {
            curByte = data[i];
            if (charByteCounter == 1) {
                if (curByte >= (byte) 0x80) {
                    while (((curByte <<= 1) & (byte) 0x80) != 0) {
                        charByteCounter++;
                    }

                    if (charByteCounter == 1 || charByteCounter > 6) {
                        return false;
                    }
                }
            } else {
                if ((curByte & (byte) 0xC0) != (byte) 0x80) {
                    return false;
                }
                charByteCounter--;
            }
        }
        if (charByteCounter > 1) {
            throw new RuntimeException("Error byte format");
        }
        return true;
    }
}
