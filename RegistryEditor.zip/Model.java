package com.reg.regedit;

import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.io.*;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Model {
    public static final boolean FIRST = true;
    public static final boolean SECOND = false;

    private static String firstFileHeader, firstFileBottom, secondFileHeader, secondFileBottom;
    private static List<String> firstFile;
    private static String firstFileEncoding;
    private static boolean isFirstFileUpper;
    private static String firstFileName;
    private static List<String> secondFile;
    private static String secondFileEncoding;
    private static boolean isSecondFileUpper;
    private static String secondFileName;

    private static List<Tuple<Tuple<Integer, Integer>, Tuple<String, String>>> firstTemplate,
            secondTemplate, template;

    public static List<String> getFirstFile() {
        return firstFile;
    }

    public static List<String> getSecondFile() {
        return secondFile;
    }

    public static List<Tuple<Tuple<Integer, Integer>, Tuple<String, String>>> getFirstTemplate() {
        return firstTemplate;
    }

    public static List<Tuple<Tuple<Integer, Integer>, Tuple<String, String>>> getSecondTemplate() {
        return secondTemplate;
    }

    public static List<Tuple<Tuple<Integer, Integer>, Tuple<String, String>>> getTemplate() {
        return template;
    }


//    static boolean loadFile(String fileName, boolean type, StringBuilder error) {
//        try {
//            Charset en = EncodingType.getType(fileName);
//            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), en));
//            StringBuilder sb = new StringBuilder();
//            String line;
//            while ((line = br.readLine()) != null) {
//                sb.append(line);
//            }
//            br.close();
//
//            int leftEdge = sb.indexOf("\"Data\"=hex:") + 11;
//            int rightEdge = sb.indexOf("\"", leftEdge + 1);
//
//            if (rightEdge == -1 || leftEdge == 10 || leftEdge > rightEdge) {
//                error.append("Файл не соответствует формату!");
//                return false;
//            }
//
//            String text = sb.substring(leftEdge, rightEdge - 1);
//            String[] tokens = text.split(",");
//            List<String> fileData = new ArrayList<>();
//            for (String token : tokens) {
//                fileData.add(token);
//            }
//
//            String header = sb.substring(0, leftEdge);
//            String bottom = sb.substring(rightEdge);
//
//            boolean upper = false;
//            for (String token : fileData) {
//                if (Character.isUpperCase(token.charAt(0))) {
//                    upper = true;
//                    break;
//                }
//            }
//
//            if (type == FIRST) {
//                firstFile = fileData;
//                firstFileHeader = header;
//                firstFileBottom = bottom;
//                isFirstFileUpper = upper;
//                firstFileEncoding = en.toString();
//                firstFileName = fileName;
//            } else {
//                secondFile = fileData;
//                secondFileHeader = header;
//                secondFileBottom = bottom;
//                isSecondFileUpper = upper;
//                secondFileEncoding = en.toString();
//                secondFileName = fileName;
//            }
//        } catch (IOException e) {
//            error.append("Ошибка открытия файла");
//            return false;
//        }
//        return true;
//    }

    public static boolean loadFile(String fileName, boolean type, StringBuilder error) {
        try {
            Charset en = EncodingType.getType(fileName);
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), en));
            StringBuilder text = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line);
            }
            br.close();

            int leftEdge = text.indexOf("\"Data\"=hex:") + 11;
            int rightEdge = text.indexOf("\"", leftEdge + 1);

            if (rightEdge == -1 || leftEdge == 10 || leftEdge > rightEdge) {
                error.append("Файл не соответствует формату!");
                return false;
            }

            StringBuilder sb = new StringBuilder(text.substring(leftEdge, rightEdge));

            if (type == FIRST) {
                String header = text.substring(0, leftEdge);
                String bottom = text.substring(rightEdge);
                boolean upper = false;
                for (int i = 0; i < sb.length(); i++) {
                    if (Character.isUpperCase(sb.charAt(i))) {
                        upper = true;
                        break;
                    }
                }


                sb = new StringBuilder(sb.toString().replace(" ", "").replace("\\", "").replace("\r\n", "").replace("\r", "")).append(",");
                String t = sb.toString();
                if (t.length() > 1) {
                    if (!t.matches("^([0-9A-Fa-f]{2}[,])*$")) {
                        error.append("Неподходящий формат поля Data");
                        return false;
                    }
                    firstFile = new ArrayList<>(Arrays.asList(sb.substring(0, sb.length() - 1).split(",")));

                } else {
                    firstFile = new ArrayList<>();
                }

                firstFileHeader = header;
                firstFileBottom = bottom;
                isFirstFileUpper = upper;
                firstFileEncoding = en.toString();
                firstFileName = fileName;
            } else {
                String header = text.substring(0, leftEdge);
                String bottom = text.substring(rightEdge);
                boolean upper = true;
                for (int i = 0; i < sb.length(); i++) {
                    if (!Character.isUpperCase(sb.charAt(i))) {
                        upper = false;
                        break;
                    }
                }

                sb = new StringBuilder(sb.toString().replace(" ", "").replace("\\", "").replace("\r\n", "").replace("\r", "")+",");
                String t = sb.toString();
                if (t.length() > 1) {
                    if (!t.matches("^([0-9A-Fa-f]{2}[,])*$")) {
                        error.append("Неподходящий формат поля Data");
                        return false;
                    }
                    secondFile = new ArrayList<>(Arrays.asList(sb.substring(0, sb.length() - 1).split(",")));
                } else {
                    secondFile = new ArrayList<>();
                }

                secondFileHeader = header;
                secondFileBottom = bottom;
                isSecondFileUpper = upper;
                secondFileEncoding = en.toString();
                secondFileName = fileName;
            }
        } catch (IOException e) {
            error.append("Ошибка открытия файла");
            return false;
        }
        return true;
    }


    public static boolean saveFile(String fileName, TableView<RowData> tableView, boolean isFirst, StringBuilder error) {
        try {
            List<String> fileData;
            StringBuilder sb = new StringBuilder();
            int rowCount = tableView.getItems().size();

            for (int i = 0; i < rowCount-1; i++) {
                RowData rowData = tableView.getItems().get(i);
                List<String> cellData = rowData.getCellData();

                for (int j = 0; j < 16; j++) {
                    if (j < cellData.size()) {
                        sb.append(cellData.get(j)).append(",");
                        if (isFirst)
                            firstFile.add(cellData.get(j));
                        else
                            secondFile.add(cellData.get(j));
                    }
                }
                sb.append("\\\r\n");
            }

            RowData lastRow = tableView.getItems().get(rowCount - 1);
            List<String> lastRowCellData = lastRow.getCellData();
            for (int i = 0; i < 16; i++) {
                if (i < lastRowCellData.size()) {
                    sb.append(lastRowCellData.get(i)).append(",");
                    if (isFirst)
                        firstFile.add(lastRowCellData.get(i));
                    else
                        secondFile.add(lastRowCellData.get(i));
                }
            }

            sb.deleteCharAt(sb.length() - 1).append("\r\n");
            String text = sb.toString();

            if (isFirst && isFirstFileUpper)
                text = text.toUpperCase();
            else if (!isFirst && isSecondFileUpper)
                text = text.toUpperCase();
            else
                text = text.toLowerCase();

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
                if (isFirst) {
                    writer.write(firstFileHeader);
                } else {
                    writer.write(secondFileHeader);
                }
                writer.newLine();
                writer.write(text);
                writer.write(isFirst ? firstFileBottom : secondFileBottom);
            }

            if (isFirst) {
                firstFileName = fileName;
            } else {
                secondFileName = fileName;
            }

            return true;
        } catch (IOException e) {
            error.append("Ошибка сохранения файла");
            return false;
        }
    }



public static boolean loadTemplate(String fileName, boolean type, StringBuilder error) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    new FileInputStream(fileName)));
            template = new ArrayList<>();
            String line;
            char[] sep = { '#' };
            while ((line = br.readLine()) != null) {
                if (line.length() < 8) {
                    error.append("Не удалось считать шаблон");
                    return false;
                }
                line = line.replace("\r\n", "").replace("\r", "");
                String[] arr = line.split(Arrays.toString(sep));
                if (arr.length != 4) {
                    error.append("Не удалось считать шаблон");
                    return false;
                }
                Tuple<Integer, Integer> coord = new Tuple<>(Integer.parseInt(arr[0]), Integer.parseInt(arr[1]));
                Tuple<String, String> val = new Tuple<>(arr[2], arr[3]);
                template.add(new Tuple<>(coord, val));
            }

            if (type == FIRST)
                firstTemplate = template;
            else
                secondTemplate = template;
            template = null;

        } catch (IOException e) {
            error.append("Ошибка чтения файла");
            return false;
        } catch (NumberFormatException e) {
            error.append("Не удалось считать шаблон");
            return false;
        }
        error.setLength(0);
        return true;
    }

    public static boolean saveTemplate(String fileName, TableView<RowData> tableView, StringBuilder error) {
        try {
            FileWriter fileWriter = new FileWriter(fileName);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            ObservableList<TableColumn<RowData, ?>> columns = tableView.getColumns();
            int rowCount = tableView.getItems().size();

//            for (RowData rowData : tableView.getItems()) {
            for(int i=0;i<rowCount; i++){


                RowData rowsData = tableView.getItems().get(i);

                String hex1 = String.valueOf(Integer.parseInt(rowsData.getRowcellData().get(i).toString(),16));
                String hex2 = Integer.toHexString(Integer.parseInt(rowsData.getColumncellData().get(i)));

                bufferedWriter.write(hex1 + "#");
                bufferedWriter.write(hex2 + "#");
                bufferedWriter.write(rowsData.getInfocellData().get(i) + "#");
                if (rowsData.getCommentcellData().get(i) != null)
                    bufferedWriter.write(rowsData.getCommentcellData().get(i));
                bufferedWriter.write("#");
                bufferedWriter.newLine();

            }

            bufferedWriter.close();
        } catch (IOException e) {
            error.append("Ошибка сохранения файла");
            return false;
        }
        error.setLength(0);
        return true;
    }

    public static boolean applyTemplate(TableView<RowData> tableView, boolean type, StringBuilder error) {
        List<Tuple<Tuple<Integer, Integer>, Tuple<String, String>>> template;
        if (type == FIRST)
            template = firstTemplate;
        else
            template = secondTemplate;

        if (template != null) {
            ObservableList<TableColumn<RowData, ?>> columns = tableView.getColumns();

            for (Tuple<Tuple<Integer, Integer>, Tuple<String, String>> tuple : template) {
                Tuple<Integer, Integer> coord = tuple.getItem1();
                int row = coord.getItem1();
                int cell = coord.getItem2();

                if (row < tableView.getItems().size()) {
                    RowData rowData = tableView.getItems().get(row);
                    if (rowData.getCellData().get(cell) != null)
                        rowData.getCellData().set(cell, tuple.getItem2().getItem1());
                    rowData.getCellData();
                }

            }
        }

        error.setLength(0);
        return true;
    }
    public static void CloseSecondFile() {
        secondFile = null;
        secondFileBottom = secondFileHeader = secondFileName = null;
    }

    // Если first = FIRST, делаем шаблон первого файла, иначе - второго
    public static void MakeTemplateByChanges(TableView<RowData> tableView, boolean type) {
        template = new ArrayList<>();

        List<String> file;
        if (type == FIRST)
            file = firstFile;
        else
            file = secondFile;

        int fileSize = file.size();
        int dgvSize = (tableView.getItems().size() - 1) * 16;
        for (int i = 0; i < 16; i++) {
            if (tableView.getItems().get(tableView.getItems().size() - 1).getCellData().get(i) != null)
                dgvSize++;
            else
                break;
        }

        int size = Math.min(fileSize, dgvSize);

        int rowCount = size / 16;
        rowCount++;
        int fileIndex = 0;

        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < 16; j++) {
                if (i == tableView.getItems().size())
                    break;
                if (tableView.getItems().get(i).getCellData().get(j) != null && (i * 16 + j) < fileSize) {
                    if (!tableView.getItems().get(i).getCellData().get(j).equalsIgnoreCase(file.get(fileIndex))) {
                        Tuple<Integer, Integer> coord = new Tuple<>(i, j);
                        Tuple<String, String> val = new Tuple<>(tableView.getItems().get(i).getCellData().get(j), "");
                        template.add(new Tuple<>(coord, val));
                    }
                    fileIndex++;
                } else break;
            }
        }
    }
}









