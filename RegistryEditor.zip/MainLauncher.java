package com.reg.regedit;

public class MainLauncher {
    public static void main(String[] args) {
        Main.main(args);
    }
}
