package com.reg.regedit;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

public class RegEditor {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private MenuItem open;

    @FXML
    private MenuItem save;

    @FXML
    private MenuItem saved;


    @FXML
    private TableView<RowData> table1;

    @FXML
    private TableView<RowData> table11;

    private TableColumn<RowData, String> headerColumn;

    private TableColumn<RowData, String>[] dataColumns;

    private File loadfirstFile;

    private File loadsecondFile;

    @FXML
    private MenuItem choose_templ;

    @FXML
    private MenuItem change_templ;

    @FXML
    private MenuItem templ_work;
    private String is_templfirst;

    private String is_templsecond;

    @FXML
    private MenuItem savesecond;

    @FXML
    private MenuItem secondopen;

    @FXML
    private MenuItem secondsaved;

    @FXML
    private MenuItem changesecond;

    @FXML
    private MenuItem choosesecond;

    @FXML
    private MenuItem applyfirst;


    @FXML
    private MenuItem applysecond;

    private boolean firstchange;
    private boolean secondchange;

    private boolean firstload;
    private boolean secondload;

    private boolean firstsave;

    private boolean secondsave;

    @FXML
    private MenuItem reloadfirst;

    @FXML
    private MenuItem reloadsecond;

    @FXML
    private Label secondtemplatename;

    @FXML
    private Label secondfilename;

    @FXML
    private Label firsttemplatename;

    @FXML
    private Label firstfilename;

    @FXML
    private MenuItem info;

    @FXML
    private MenuItem templinfo;

    private Stage newstage;

    @FXML
    void initialize() {
        final FileChooser fileChooser = new FileChooser();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Сохранение файла");
        alert.setHeaderText(null);

        Alert inform = new Alert(Alert.AlertType.INFORMATION);
        inform.setTitle("Справка: Работа с файлами реестра");
        inform.setHeaderText(null);
        inform.setContentText("Начальный режим - режим выбора строк. Для перехода в режим редактирования и выбора ячеек нажмите Ctrl+E\n\nДля удаления ячеек выберете ячейку и нажмите Ctrl+R.\n\nДля удаления строк выберете строку и нажмите Ctrl+D.\n\nЗамечание: Если при внесении изменений ячейка в одной из таблиц не изменила цвет, то для этого следует выбрать эту таблицу при помощи мыши и нажать Shift.");
        Alert informtemp = new Alert(Alert.AlertType.INFORMATION);
        informtemp.setTitle("Работа с шаблонами");
        informtemp.setHeaderText(null);
        informtemp.setContentText("Работа с шаблонами осуществляется c помощью кнопок расположенных в окне.");


        reloadfirst.setDisable(true);
        reloadsecond.setDisable(true);
        secondopen.setDisable(true);
        save.setDisable(true);
        savesecond.setDisable(true);
        saved.setDisable(true);
        secondsaved.setDisable(true);
        change_templ.setDisable(true);
        changesecond.setDisable(true);
        applyfirst.setDisable(true);
        applysecond.setDisable(true);
        choose_templ.setDisable(true);
        changesecond.setDisable(true);
        choosesecond.setDisable(true);

        tableCreate(table1);
        tableCreate(table11);

        Tooltip tooltip = new Tooltip();

        table1.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.isShiftDown() ) {
                table1.refresh();

            }
        });
        table11.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.isShiftDown() ) {
                table11.refresh();

            }
        });
        info.setOnAction(actionEvent -> {
            inform.showAndWait();
                });
        templinfo.setOnAction(actionEvent -> {
            informtemp.showAndWait();
        });


        open.setOnAction(actionEvent -> {
            List<String> extensions = Arrays.asList("*.reg");
            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Файлы реестра", extensions);
            fileChooser.getExtensionFilters().add(extFilter);
            if(firstload==true){
                Alert newalert = new Alert(Alert.AlertType.CONFIRMATION);
                newalert.setTitle("Смена файла");
                newalert.setHeaderText("Вы уверены, что хотите сменить первый файл?");
                newalert.setContentText("Все несохраненные данные будут потеряны.");
                ButtonType closeButton = new ButtonType("Сменить", ButtonBar.ButtonData.OK_DONE);
                ButtonType cancelButton = new ButtonType("Отмена", ButtonBar.ButtonData.CANCEL_CLOSE);
                newalert.getButtonTypes().setAll(closeButton, cancelButton);
                ButtonType result = newalert.showAndWait().orElse(ButtonType.CANCEL);
                if (result == closeButton) {
                    loadfirstFile = fileChooser.showOpenDialog(new Stage());
                }
            }
            else{
                loadfirstFile = fileChooser.showOpenDialog(new Stage());
            }
            if (loadfirstFile != null) {
                StringBuilder err = new StringBuilder();
                if (Model.loadFile(loadfirstFile.getAbsolutePath(), Model.FIRST, err)) {
                    fileLoading(table1, Model.FIRST, loadfirstFile.getAbsolutePath(), 1);
                    firstload = true;
                    firstfilename.setText("Файл: "+ loadfirstFile.getAbsolutePath());
                    save.setDisable(false);
                    saved.setDisable(false);
                    saved.setText(saved.getText() + " (" + loadfirstFile.getAbsolutePath() + ")");
                    secondopen.setDisable(false);
                    reloadfirst.setDisable(false);
                    reloadfirst.setText(reloadfirst.getText() + " (" + loadfirstFile.getAbsolutePath() + ")");
                    choose_templ.setDisable(false);
                } else {
                    Alert filealert = new Alert(Alert.AlertType.ERROR);
                    filealert.setTitle("Ошибка открытия файла");
                    filealert.setHeaderText(null);
                    filealert.setContentText(err.toString());
                    filealert.showAndWait();
                }
            }
        });

        secondopen.setOnAction(actionEvent -> {
            List<String> extensions = Arrays.asList("*.reg");
            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Файлы реестра", extensions);
            fileChooser.getExtensionFilters().add(extFilter);
            if(secondload==true) {
                Alert newalert = new Alert(Alert.AlertType.CONFIRMATION);
                newalert.setTitle("Смена файла");
                newalert.setHeaderText("Вы уверены, что хотите сменить второй файл?");
                newalert.setContentText("Все несохраненные данные будут потеряны.");
                // Получение кнопок в диалоговом окне
                ButtonType closeButton = new ButtonType("Сменить", ButtonBar.ButtonData.OK_DONE);
                ButtonType cancelButton = new ButtonType("Отмена", ButtonBar.ButtonData.CANCEL_CLOSE);
                newalert.getButtonTypes().setAll(closeButton, cancelButton);
                ButtonType result = newalert.showAndWait().orElse(ButtonType.CANCEL);
                if (result == closeButton) {
                    loadsecondFile = fileChooser.showOpenDialog(new Stage());
                }
            }
            else {
                loadsecondFile = fileChooser.showOpenDialog(new Stage());
            }
            if (loadsecondFile != null) {
//                tooltip.setText("Файл: " + loadFile.getAbsolutePath());
//                table1.setTooltip(tooltip);
                StringBuilder err = new StringBuilder();
                if (Model.loadFile(loadsecondFile.getAbsolutePath(), Model.SECOND, err)) {
                    fileLoading(table11, Model.SECOND, loadsecondFile.getAbsolutePath(), 2);
                    secondload = true;
                    secondfilename.setText("Файл: "+ loadsecondFile.getAbsolutePath());
                    reloadsecond.setDisable(false);
                    reloadsecond.setText(reloadsecond.getText() + " (" + loadsecondFile.getAbsolutePath() + ")");
                    secondsaved.setText(secondsaved.getText() + " (" + loadsecondFile.getAbsolutePath() + ")");
                    savesecond.setDisable(false);
                    secondsaved.setDisable(false);
                    choosesecond.setDisable(false);
                    compareValues();
                } else {
                    Alert filealert = new Alert(Alert.AlertType.ERROR);
                    filealert.setTitle("Ошибка открытия файла");
                    filealert.setHeaderText(null);
                    filealert.setContentText(err.toString());
                    filealert.showAndWait();
                }
            }
        });

        secondsaved.setOnAction(actionEvent -> {
            if (Model.getSecondFile() != null) {
                StringBuilder err = new StringBuilder();
                if (!Model.saveFile(loadsecondFile.getAbsolutePath(), table11, Model.SECOND, err)) {
                    Alert filealert = new Alert(Alert.AlertType.ERROR);
                    filealert.setTitle("Ошибка сохранения файла");
                    filealert.setHeaderText(null);
                    filealert.setContentText(err.toString());
                    filealert.showAndWait();
                } else {
                    alert.setContentText("Файл успешно сохранен.");
                    alert.showAndWait();
                }
            }
        });

        savesecond.setOnAction(actionEvent -> {
            if (Model.getSecondFile() != null) {
                File saveFile = fileChooser.showSaveDialog(new Stage());
                StringBuilder err = new StringBuilder();
                if (!Model.saveFile(saveFile.getAbsolutePath(), table11, Model.SECOND, err)) {
                    Alert filealert = new Alert(Alert.AlertType.ERROR);
                    filealert.setTitle("Ошибка сохранения файла");
                    filealert.setHeaderText(null);
                    filealert.setContentText(err.toString());
                    filealert.showAndWait();
                }
            }
        });

        choose_templ.setOnAction(actionEvent -> {
            FileChooser filesChooser = new FileChooser();
            filesChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Файлы", "*.tmpl"));
            File selectedFile = filesChooser.showOpenDialog(null);
            if (selectedFile != null) {
                StringBuilder err = new StringBuilder();
                if (Model.loadTemplate(selectedFile.getAbsolutePath(), Model.FIRST, err)) {
                    is_templfirst = selectedFile.getAbsolutePath();
                    change_templ.setText(change_templ.getText() + " (" + is_templfirst + ")");
                    applyfirst.setText(applyfirst.getText() + " (" + is_templfirst + ")");
                    firsttemplatename.setText("Шаблон: "+ is_templfirst);
                    change_templ.setDisable(false);
                    applyfirst.setDisable(false);
                } else {
                    Alert filealert = new Alert(Alert.AlertType.ERROR);
                    filealert.setTitle("Ошибка выбора шаблона");
                    filealert.setHeaderText(null);
                    filealert.setContentText(err.toString());
                    filealert.showAndWait();
                }
            }
        });

        change_templ.setOnAction(actionEvent -> {
            if (Model.getFirstTemplate() != null) {

                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/template.fxml"));
                    newstage = new Stage();
                    newstage.setScene(new Scene((Pane) loader.load()));
                    newstage.setTitle("Изменение шаблона");
                    newstage.setResizable(false);
                    newstage.setFullScreen(false);
                    newstage.setMaximized(false);
                    newstage.setOnCloseRequest(this::handleWindowCloseRequest);

                    TemplateController templateController = loader.getController();
                    templateController.setTemplatedata(is_templfirst, 1, Model.FIRST);
                    newstage.show();

                } catch (IOException e) {
                    e.printStackTrace();
                    Alert filealert = new Alert(Alert.AlertType.ERROR);
                    filealert.setTitle("Ошибка открытия шаблона");
                    filealert.setHeaderText(null);
                    filealert.setContentText(e.toString());
                    filealert.showAndWait();
                }

            }
        });

        choosesecond.setOnAction(actionEvent -> {
            FileChooser filesChooser = new FileChooser();
            filesChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Файлы", "*.tmpl"));
            File selectedFile = filesChooser.showOpenDialog(null);

            if (selectedFile != null) {
                StringBuilder err = new StringBuilder();
                if (Model.loadTemplate(selectedFile.getAbsolutePath(), Model.SECOND, err)) {
                    is_templsecond = selectedFile.getAbsolutePath();
                    changesecond.setText(changesecond.getText() + " (" + is_templsecond + ")");
                    applysecond.setText(applysecond.getText() + " (" + is_templsecond + ")");
                    secondtemplatename.setText("Шаблон: "+ is_templsecond);
                    changesecond.setDisable(false);
                    applysecond.setDisable(false);
                } else {
                    Alert filealert = new Alert(Alert.AlertType.ERROR);
                    filealert.setTitle("Ошибка выбора шаблона");
                    filealert.setHeaderText(null);
                    filealert.setContentText(err.toString());
                    filealert.showAndWait();
                }
            }
        });

        changesecond.setOnAction(actionEvent -> {
            if (Model.getSecondTemplate() != null) {

                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/template.fxml"));
                    newstage = new Stage();
                    newstage.setScene(new Scene((Pane) loader.load()));
                    newstage.setTitle("Изменение шаблона");
                    newstage.setResizable(false);
                    newstage.setFullScreen(false);
                    newstage.setMaximized(false);
                    newstage.setOnCloseRequest(this::handleWindowCloseRequest);

                    TemplateController templateController = loader.getController();
                    templateController.setTemplatedata(is_templsecond, 1, Model.SECOND);
                    newstage.show();

                } catch (IOException e) {
                    Alert filealert = new Alert(Alert.AlertType.ERROR);
                    filealert.setTitle("Ошибка открытия шаблона");
                    filealert.setHeaderText(null);
                    filealert.setContentText(e.toString());
                    filealert.showAndWait();
                    e.printStackTrace();
                }

            }
        });

        saved.setOnAction(actionEvent -> {
            if (Model.getFirstFile() != null) {
                StringBuilder err = new StringBuilder();
                if (!Model.saveFile(loadfirstFile.getAbsolutePath(), table1, Model.FIRST, err)) {
                    Alert filealert = new Alert(Alert.AlertType.ERROR);
                    filealert.setTitle("Ошибка сохранения файла");
                    filealert.setHeaderText(null);
                    filealert.setContentText(err.toString());
                    filealert.showAndWait();
                } else {
                    alert.setContentText("Файл успешно сохранен.");
                    alert.showAndWait();
                }
            }
        });

        templ_work.setOnAction(actionEvent -> {

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/template.fxml"));
                Parent root = loader.load();

                newstage = new Stage();

                newstage.setScene(new Scene(root));

                newstage.setTitle("Создание шаблона");
                newstage.setResizable(false);
                newstage.setMaximized(false);
                newstage.setFullScreen(false);
                newstage.setOnCloseRequest(this::handleWindowCloseRequest);


                newstage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }


        });

        save.setOnAction(actionEvent -> {
            if (Model.getFirstFile() != null) {
                File saveFile = fileChooser.showSaveDialog(new Stage());
                StringBuilder err = new StringBuilder();
                if (!Model.saveFile(saveFile.getAbsolutePath(), table1, Model.FIRST, err)) {
                    Alert filealert = new Alert(Alert.AlertType.ERROR);
                    filealert.setTitle("Ошибка сохранения файла");
                    filealert.setHeaderText(null);
                    filealert.setContentText(err.toString());
                    filealert.showAndWait();
                }

            }
        });

        applyfirst.setOnAction(actionEvent -> {

            StringBuilder err = new StringBuilder();
            Model.applyTemplate(table1, Model.FIRST, err);
//            Alert templalert = new Alert(Alert.AlertType.ERROR);
//            templalert.setTitle("Ошибка применения шаблона");
//            templalert.setHeaderText(null);
//            templalert.setContentText(err.toString());
//            templalert.showAndWait();
            table1.refresh();
            table11.refresh();

        });

        applysecond.setOnAction(actionEvent -> {

            StringBuilder err = new StringBuilder();
            Model.applyTemplate(table11, Model.SECOND, err);
            table11.refresh();
            table1.refresh();

        });

        reloadfirst.setOnAction(actionEvent -> {
            fileLoading(table1, Model.FIRST, loadfirstFile.getAbsolutePath(), 1);
        });

        reloadsecond.setOnAction(actionEvent -> {
            fileLoading(table11, Model.SECOND, loadsecondFile.getAbsolutePath(), 2);
        });

    }

    private void tableCreate(TableView<RowData> tabl) {
        String cssFilePath = getClass().getResource("/error.css").toExternalForm();
        tabl.getStylesheets().add(cssFilePath);
        tabl.requestFocus();
        tabl.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.isControlDown() && event.getCode() == KeyCode.R) {
                removeSelectedCell(tabl);
            }
        });

        tabl.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.isControlDown() && event.getCode() == KeyCode.D) {
                deletingRows(tabl);
            }
        });
        tabl.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if (event.isControlDown() && event.getCode() == KeyCode.E) {
                if (tabl.getSelectionModel().isCellSelectionEnabled()) {
                    tabl.getSelectionModel().setCellSelectionEnabled(false);
                    tabl.setEditable(false);
                } else {
                    tabl.getSelectionModel().setCellSelectionEnabled(true);
                    tabl.setEditable(true);
                }
            }
        });
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка ввода данных");
        alert.setHeaderText(null);
        tabl.getColumns().clear();
        tabl.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        headerColumn = new TableColumn<>("");
        headerColumn.setCellValueFactory(new PropertyValueFactory<>("header"));
        headerColumn.setPrefWidth(40);
        headerColumn.setSortable(false);
        headerColumn.setEditable(false);
        headerColumn.setReorderable(false);
        headerColumn.setResizable(false);

        tabl.getColumns().add(0, headerColumn);
        dataColumns = new TableColumn[16];

        for (int j = 0; j < 16; j++) {
            TableColumn<RowData, String> dataColumn = new TableColumn<>(String.format("%02X", j));
            final int columnIndex = j;
            dataColumn.setCellValueFactory(cellData -> {
                RowData rowData = cellData.getValue();
                if (columnIndex < rowData.getCellData().size()) {
                    return new SimpleStringProperty(rowData.getCellData().get(columnIndex));
                } else {
                    return new SimpleStringProperty("");
                }
            });
            dataColumn.setResizable(true);
            dataColumn.setPrefWidth(40);
            dataColumn.setEditable(true);
            dataColumn.setSortable(false);
            dataColumn.setReorderable(false);
            dataColumn.setResizable(false);
            dataColumn.setCellFactory(column -> {
                return new TableCell<RowData, String>() {
                    private final TextField textField = new TextField();
                    private final Tooltip tooltip = new Tooltip();

                    {
                        textField.setOnKeyPressed(event -> {
                            if (event.getCode() == KeyCode.ENTER) {
                                commitEdit(textField.getText());
                            } else if (event.getCode() == KeyCode.ESCAPE) {
                                cancelEdit();
                            }
                        });
                    }

                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if (isEditing()) {
                            setText(null);
                            setGraphic(textField);
                        } else {

                            setText(item);
                            setGraphic(null);
                        }
                        if (empty || item == null) {
                            setTooltip(null);
                            textField.requestFocus();
                        } else {
                            tooltip.setText(item);
                            setTooltip(tooltip);
                            setGraphic(null);
                        }
                    }

                    @Override
                    public void startEdit() {
                        super.startEdit();

                        textField.setText(getItem());
                        setText(null);
                        setGraphic(textField);
                        textField.requestFocus();
                    }

                    @Override
                    public void cancelEdit() {
                        super.cancelEdit();
                        setText(getItem());
                        setGraphic(null);

                    }

                    @Override
                    public void commitEdit(String newValue) {
                        super.commitEdit(newValue);
                        TablePosition<RowData, String> pos = getTableView().getSelectionModel().getSelectedCells().get(0);
                        int row = pos.getRow();
                        int column = pos.getColumn() - 1;
                        RowData rowData = getTableView().getItems().get(row);
                        String prevValue = rowData.getCellData().get(column);

                        if (newValue.contains(" ") || newValue.isEmpty()) {
                            alert.setContentText("Значение не должно содержать пробелов и быть пустым!");
                            alert.showAndWait();
                            rowData.setCellData(column, prevValue);
                            getTableView().refresh();
                            return;
                        }

                        try {
                            int num = Integer.parseInt(newValue, 16);
                        } catch (NumberFormatException ex) {
                            alert.setContentText("Некорректный символ!");
                            alert.showAndWait();
                            rowData.setCellData(column, prevValue);
                            getTableView().refresh();
                            return;
                        }

                        if (newValue.length() == 2) {
                            rowData.setCellData(column, newValue);
                            getTableView().refresh();
                        } else {
                            alert.setContentText("Значение должно содержать два символа!");
                            alert.showAndWait();
                            rowData.setCellData(column, prevValue);
                            getTableView().refresh();
                        }
                    }

                };
            });
            dataColumns[j] = dataColumn;
        }
        tabl.getColumns().addAll(dataColumns);
        tabl.setPrefSize(692, 725);
        tabl.autosize();
        tabl.refresh();
    }

    private void removeSelectedCell(TableView<RowData> tableView) {
        ObservableList<TablePosition> selectedCells = tableView.getSelectionModel().getSelectedCells();

        if (!selectedCells.isEmpty()) {
            TablePosition<RowData, ?> selectedCell = selectedCells.get(0);
            int rowIndex = selectedCell.getRow();
            int columnIndex = selectedCell.getColumn();
            RowData rowData = tableView.getItems().get(rowIndex);
            List<String> cellData = rowData.getCellData();
            cellData.remove(columnIndex - 1);
            for (int i = rowIndex; i < tableView.getItems().size(); i++) {
                RowData currentRow = tableView.getItems().get(i);
                RowData lastRow = tableView.getItems().get(tableView.getItems().size() - 1);
                List<String> currentCellData = currentRow.getCellData();
                if (i == rowIndex) {
                    if (lastRow.getCellData().isEmpty()) {
                        ObservableList<RowData> items = tableView.getItems();
                        items.remove(tableView.getItems().size() - 1);
                    }
                    if (i < tableView.getItems().size() - 1) {
                        List<String> nextCellData = tableView.getItems().get(i + 1).getCellData();
                        currentCellData.add(nextCellData.get(0));
                    } else {
                        currentCellData.remove(columnIndex - 1);
                    }
                } else {
                    if (lastRow.getCellData().isEmpty()) {
                        ObservableList<RowData> items = tableView.getItems();
                        items.remove(tableView.getItems().size() - 1);
                    }
                    if (!currentCellData.isEmpty()) {
                        if (i < tableView.getItems().size() - 1) {
                            currentCellData.remove(0);
                            List<String> nextCellData = tableView.getItems().get(i + 1).getCellData();
                            currentCellData.add(nextCellData.get(0));
                        } else {
                            if (currentCellData.size() < columnIndex) {
                                currentCellData.remove(currentCellData.size() - 1);
                            } else {
                                currentCellData.remove(0);
                            }
                        }
                    }

                }
            }
            tableView.refresh();
//            table11.refresh();
//            table1.refresh();
        }
    }


    private void fileLoading(TableView<RowData> table, boolean type, String filename, int filetype) {

        table.getItems().clear();
        int size;
        if (filetype == 1) {
            size = Model.getFirstFile().size();
        } else {
            size = Model.getSecondFile().size();
        }

        int rowCount = size / 16;
        if ((size - 16 * rowCount) > 0)
            rowCount++;

        int counter = 0;
        for (int i = 0; i < rowCount; i++) {
            table.getItems().add(new RowData(Integer.toHexString(i).toUpperCase()));
            for (int j = 0; j < 16; j++) {
                if (counter == size)
                    break;
                if (filetype == 1) {
                    table.getItems().get(i).addCellData(Model.getFirstFile().get(counter++).toUpperCase());
                } else {
                    table.getItems().get(i).addCellData(Model.getSecondFile().get(counter++).toUpperCase());
                }
            }
        }
    }


    private void compareValues() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка ввода данных");
        alert.setHeaderText(null);
        for (int row = 0; row < table1.getItems().size(); row++) {
            // Обход всех столбцов таблицы
            for (int col = 0; col < table1.getColumns().size() - 1; col++) {
                // Получение позиции текущей ячейки
                TablePosition<RowData, String> position = (TablePosition<RowData, String>) new TablePosition<>(table1, row, table1.getColumns().get(col + 1));
                final int columnIndex = col;
                final int rowIndex = row;
                position.getTableColumn().setCellValueFactory(cellData -> {
                    RowData rowData = cellData.getValue();
                    if (columnIndex < rowData.getCellData().size()) {
                        return new SimpleStringProperty(rowData.getCellData().get(columnIndex));
                    } else {
                        return new SimpleStringProperty("");
                    }
                });
                position.getTableColumn().setCellFactory(column -> {
                    return new TableCell<RowData, String>() {

                        private final TextField textField = new TextField();
                        private final Tooltip tooltip = new Tooltip();

                        {
                            textField.setOnKeyPressed(event -> {
                                if (event.getCode() == KeyCode.ENTER) {
                                    commitEdit(textField.getText());
                                } else if (event.getCode() == KeyCode.ESCAPE) {
                                    cancelEdit();
                                }
                            });
                        }

                        @Override
                        protected void updateItem(String item, boolean empty) {
                            super.updateItem(item, empty);
                            if (isEditing()) {
                                setText(null);
                                setGraphic(textField);
                            } else {
                                setText(item);
                                setGraphic(null);
                            }
                            if (empty || item == null) {
                                setTooltip(null);
                                textField.requestFocus();
                            } else {
                                tooltip.setText(item);
                                setTooltip(tooltip);
                                setGraphic(null);
                                if (getIndex() < table11.getItems().size()) {
                                    String cellValue = new String();
                                    RowData rowData = table11.getItems().get(getIndex());
                                    if (columnIndex < rowData.getCellData().size()) {
                                        cellValue = rowData.getCellData().get(columnIndex);
                                    }
                                    boolean contains = item.trim().contains(cellValue.trim().toUpperCase());
                                    if (contains) {
                                        getStyleClass().add("equal-cell");
                                    }
                                    if (!contains) {
                                        getStyleClass().removeAll("equal-cell");
                                    }
                                } else {
                                    getStyleClass().removeAll("equal-cell");
                                }
                            }
                        }

                        @Override
                        public void startEdit() {
                            super.startEdit();
                            textField.setText(getItem());
                            setText(null);
                            setGraphic(textField);
                            textField.requestFocus();
                        }

                        @Override
                        public void cancelEdit() {
                            super.cancelEdit();
                            setText(getItem());
                            setGraphic(null);

                        }

                        @Override
                        public void commitEdit(String newValue) {
                            super.commitEdit(newValue);
                            TablePosition<RowData, String> pos = getTableView().getSelectionModel().getSelectedCells().get(0);
                            int row = pos.getRow();
                            int column = pos.getColumn() - 1;
                            RowData rowData = getTableView().getItems().get(row);
                            String prevValue = rowData.getCellData().get(column);

                            if (newValue.contains(" ") || newValue.isEmpty()) {
                                alert.setContentText("Значение не должно содержать пробелов и быть пустым!");
                                alert.showAndWait();
                                rowData.setCellData(column, prevValue);
                                return;
                            }
                            try {
                                int num = Integer.parseInt(newValue, 16);
                            } catch (NumberFormatException ex) {
                                alert.setContentText("Некорректный символ!");
                                alert.showAndWait();
                                rowData.setCellData(column, prevValue);
                                return;
                            }
                            if (newValue.length() == 2) {
                                if (getIndex() < table11.getItems().size()) {
                                    String cellValue = new String();
                                    RowData rowsData = table11.getItems().get(getIndex());
                                    if (columnIndex < rowsData.getCellData().size()) {
                                        cellValue = rowsData.getCellData().get(columnIndex);
                                    }
                                    if (!prevValue.equals(cellValue)) {
                                        rowsData.setCellData(columnIndex, newValue);
                                        table11.refresh();
                                    }
                                }
                                rowData.setCellData(column, newValue);
                                getTableView().refresh();
                            } else {
                                alert.setContentText("Значение должно содержать два символа!");
                                alert.showAndWait();
                                rowData.setCellData(column, prevValue);
                            }
                        }

                    };

                });

            }
        }
        table1.refresh();
        for (int row = 0; row < table11.getItems().size(); row++) {
            for (int col = 0; col < table11.getColumns().size() - 1; col++) {
                TablePosition<RowData, String> position1 = (TablePosition<RowData, String>) new TablePosition<>(table11, row, table11.getColumns().get(col + 1));

                final int columnIndex = col;
                final int rowIndex = row;


                position1.getTableColumn().setCellFactory(column -> {
                    return new TableCell<RowData, String>() {


                        private final TextField textField = new TextField();
                        private final Tooltip tooltip = new Tooltip();

                        {
                            textField.setOnKeyPressed(event -> {
                                if (event.getCode() == KeyCode.ENTER) {
                                    commitEdit(textField.getText());
                                } else if (event.getCode() == KeyCode.ESCAPE) {
                                    cancelEdit();
                                }
                            });
                        }

                        @Override
                        protected void updateItem(String item, boolean empty) {
                            super.updateItem(item, empty);
                            if (isEditing()) {
                                setText(null);
                                setGraphic(textField);
                            } else {
                                setText(item);
                                setGraphic(null);
                            }
                            if (empty || item == null) {
                                getStyleClass().removeAll("equal-cell");
                                getStyleClass().removeAll("nonequal-cell");
                                setTooltip(null);
                                textField.requestFocus();
                            } else {
                                tooltip.setText(item);
                                setTooltip(tooltip);
                                setGraphic(null);
                                if (getIndex() < table1.getItems().size()) {
                                    String cellValue = new String();
                                    RowData rowData = table1.getItems().get(getIndex());
                                    if (columnIndex < rowData.getCellData().size()) {
                                        cellValue = rowData.getCellData().get(columnIndex);
                                    }
                                    boolean contains = item.trim().contains(cellValue.trim().toUpperCase());
                                    if (contains) {
                                        getStyleClass().add("equal-cell");
                                    }
                                    if (!contains) {
                                        getStyleClass().removeAll("equal-cell");
                                    }
                                } else {
                                    getStyleClass().removeAll("equal-cell");

                                }
                            }
                        }

                        @Override
                        public void startEdit() {
                            super.startEdit();
                            textField.setText(getItem());
                            setText(null);
                            setGraphic(textField);
                            textField.requestFocus();
                        }

                        @Override
                        public void cancelEdit() {
                            super.cancelEdit();
                            setText(getItem());
                            setGraphic(null);

                        }

                        @Override
                        public void commitEdit(String newValue) {
                            super.commitEdit(newValue);
                            TablePosition<RowData, String> pos = getTableView().getSelectionModel().getSelectedCells().get(0);
                            int row = pos.getRow();
                            int column = pos.getColumn() - 1;
                            RowData rowData = getTableView().getItems().get(row);
                            String prevValue = rowData.getCellData().get(column);

                            if (newValue.contains(" ") || newValue.isEmpty()) {
                                alert.setContentText("Значение не должно содержать пробелов и быть пустым!");
                                alert.showAndWait();
                                rowData.setCellData(column, prevValue);
                                return;
                            }

                            try {
                                int num = Integer.parseInt(newValue, 16);
                            } catch (NumberFormatException ex) {
                                alert.setContentText("Некорректный символ!");
                                alert.showAndWait();
                                rowData.setCellData(column, prevValue);
                                return;
                            }

                            if (newValue.length() == 2) {

                                if (getIndex() < table1.getItems().size()) {
                                    String cellValue = new String();
                                    RowData rowsData = table1.getItems().get(getIndex());
                                    if (columnIndex < rowsData.getCellData().size()) {
                                        cellValue = rowsData.getCellData().get(columnIndex);
                                    }
                                    if (!prevValue.equals(cellValue)) {
                                        rowsData.setCellData(columnIndex, newValue);
                                        table1.refresh();

                                    }
                                }
                                rowData.setCellData(column, newValue);
                                getTableView().refresh();
                            } else {
                                alert.setContentText("Значение должно содержать два символа!");
                                alert.showAndWait();
                                rowData.setCellData(column, prevValue);

                            }
                        }

                    };

                });

            }
        }
        table11.refresh();
        table1.refresh();
    }


    private void deletingRows(TableView<RowData> tableView) {

        ObservableList<RowData> data = tableView.getItems(); // Список элементов таблицы


        int selectedIndex = tableView.getSelectionModel().getSelectedIndex();


        if (selectedIndex >= 0) {
            RowData checkdata = data.get(selectedIndex);

            data.remove(selectedIndex);


            if (selectedIndex < data.size() && !checkdata.getCellData().isEmpty()) {
                for (int i = selectedIndex; i < data.size(); i++) {
                    RowData currentRow = data.get(i);


                }
            }
            RowData lastrow = data.get(data.size() - 1);

            // Проверка и удаление последней пустой строки
            if (data.size() > 0 && checkdata.getCellData().isEmpty()) {
                data.remove(data.size() - 1);
            }

            // Обновление таблицы
        }
    }

    private void handleWindowCloseRequest(WindowEvent event) {
        // Создание диалогового окна с вопросом

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Подтверждение закрытия");
        alert.setHeaderText("Вы уверены, что хотите закрыть окно?");
        alert.setContentText("Все несохраненные данные будут потеряны.");

        // Получение кнопок в диалоговом окне
        ButtonType closeButton = new ButtonType("Закрыть", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Отмена", ButtonBar.ButtonData.CANCEL_CLOSE);
        alert.getButtonTypes().setAll(closeButton, cancelButton);

        // Ожидание ответа пользователя
        ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);

        // Проверка выбранной кнопки
        if (result == closeButton) {
            // Закрытие окна
           newstage.close();
        } else {
            // Отмена закрытия окна
            event.consume();
        }
    }

}










    





