package com.reg.regedit;
import javafx.beans.property.ListProperty;
import javafx.beans.property.ReadOnlyListProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class RowData {
    private String header;
    private ObservableList<String> cellData;
//    private ObservableList<String> status;


    private ListProperty<String> status;
    private ObservableList<String> RowcellData;
    private ObservableList<String> ColumncellData;
    private ObservableList<String> InfocellData;
    private ObservableList<String> CommentcellData;
    private ObservableList<ObservableList<String>> commentCellDataList;

    public RowData() {
        this.RowcellData = FXCollections.observableArrayList();
        this.ColumncellData = FXCollections.observableArrayList();
        this.CommentcellData = FXCollections.observableArrayList();
        this.InfocellData = FXCollections.observableArrayList();
        this.commentCellDataList = FXCollections.observableArrayList();
        this.status = new SimpleListProperty<>(FXCollections.observableArrayList());
    }
    public RowData(String header) {
        this.header = header;
        this.cellData = FXCollections.observableArrayList();
        this.status = new SimpleListProperty<>(FXCollections.observableArrayList());
    }

    public RowData(String row, String column, String info,String comment){
        RowcellData.add(row);
        ColumncellData.add(column);
        InfocellData.add(info);
        CommentcellData.add(comment);
    }



    public String getHeader() {
        return header;
    }

    public ObservableList<String> getCellData() {
        return cellData;
    }

    public void addCellData(String data) {
        cellData.add(data);
    }

    public void setCellData(int index, String data) {
        cellData.set(index, data);
    }


    public ObservableList<String> getStatus() {
        return status.get();
    }

    public void setStatus(ObservableList<String> status) {
        this.status.set(status);
    }

    public ReadOnlyListProperty<String> statusProperty() {
        return status;
    }

    public void addStatusData(String data) {
        status.add(data);
    }


    public ObservableList<String> getRowcellData() {
        return RowcellData;
    }

    public void addRowcellData(String data) {
        RowcellData.add(data);
    }

    public void setRowcellData(int index, String data) {
        RowcellData.set(index, data);
    }

    public ObservableList<String> getColumncellData() {
        return ColumncellData;
    }

    public void addColumncellData(String data) {
        ColumncellData.add(data);
    }

    public void setColumncellData(int index, String data) {
        ColumncellData.set(index, data);
    }


    public ObservableList<String> getInfocellData() {
        return InfocellData;
    }

    public void addInfocellData(String data) {
        InfocellData.add(data);
    }

    public void setInfocellData(int index, String data) {
        InfocellData.set(index, data);
    }

    public ObservableList<String> getCommentcellData() {
        return CommentcellData;
    }

    public void addCommentcellData(String data) {CommentcellData.add(data);}

    public void setCommentcellData(int index, String data) {CommentcellData.set(index, data);}

    public ObservableList<ObservableList<String>> getCommentCellDataList() {
        return commentCellDataList;
    }

//    public String getColumn() {
//        return column;
//    }
//
//    public void setColumn(String column) {
//        this.column = column;
//    }
//
//    public String getComment() {
//        return comment;
//    }
//
//    public void setComment(String comment) {
//        this.comment = comment;
//    }
//
//    public String getFirst() {
//        return first;
//    }
//
//    public void setFirst(String first) {
//        this.first = first;
//    }
//
//    public String getInfo() {
//        return info;
//    }
//
//    public void setInfo(String info) {
//        this.info = info;
//    }
//
//    public String getRow() {
//        return row;
//    }
//
//    public void setRow(String row) {
//        this.row = row;
//    }

}
