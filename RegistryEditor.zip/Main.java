package com.reg.regedit;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/main.fxml"));

        Parent root = loader.load();

        Scene scene = new Scene(root,300,275);
        scene.getStylesheets().add(getClass().getResource("/error.css").toExternalForm());


        stage.setTitle("Редактор файлов реестра");

        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();


        stage.setX(screenBounds.getMinX());
        stage.setY(screenBounds.getMinY());
        stage.setWidth(screenBounds.getWidth());
        stage.setHeight(screenBounds.getHeight());
        stage.setFullScreen(false);
        stage.setMaximized(true);
        stage.setOnCloseRequest(this::handleWindowCloseRequest);

        stage.setResizable(true);

        stage.setScene(scene);




        stage.show();

    }
    public static void main(String[] args) {
        launch(args);
    }

    private void handleWindowCloseRequest(WindowEvent event) {
        // Создание диалогового окна с вопросом
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Подтверждение закрытия");
        alert.setHeaderText("Вы уверены, что хотите закрыть окно?");
        alert.setContentText("Все несохраненные данные будут потеряны.");

        // Получение кнопок в диалоговом окне
        ButtonType closeButton = new ButtonType("Закрыть", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Отмена", ButtonBar.ButtonData.CANCEL_CLOSE);
        alert.getButtonTypes().setAll(closeButton, cancelButton);

        // Ожидание ответа пользователя
        ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);

        // Проверка выбранной кнопки
        if (result == closeButton) {
            // Закрытие окна
            Platform.exit();
        } else {
            // Отмена закрытия окна
            event.consume();
        }
    }

}



